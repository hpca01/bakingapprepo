package com.example.hiren_pc_hp.popularmoviesapp1.utils;
import com.example.hiren_pc_hp.popularmoviesapp1.data.MoviesResponse;

import retrofit2.Call;
import retrofit2.http.GET;


public interface MovieService {
    public String popular = "movie/popular?api_key=0dff3be5cf5aefa28a90cd35ef65288c";
    @GET(popular) Call<MoviesResponse> getPopularMovies();

    public String highestRated = "movie/top_rated?api_key=0dff3be5cf5aefa28a90cd35ef65288c";
    @GET(highestRated) Call<MoviesResponse> getHighestMovies();
}

